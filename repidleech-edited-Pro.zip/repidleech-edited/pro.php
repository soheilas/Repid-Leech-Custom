<?php
$page = file_get_contents('https://openproxy.space/proxy-list/country/iran');
preg_match_all("/([0-9]){1,3}\.([0-9]){1,3}\.([0-9]){1,3}\.([0-9]){1,2}\:([0-9]){1,2}/", $page, $matches);

foreach($matches[0] as $match) {
    echo $match . "<br>";
}

?>