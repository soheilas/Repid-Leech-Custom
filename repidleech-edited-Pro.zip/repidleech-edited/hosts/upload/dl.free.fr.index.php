<?php
$upload_services[]="dl.free.fr";
$max_file_size["dl.free.fr"]=1024;
$page_upload["dl.free.fr"] = "dl.free.fr.php";  
?>