<?php
$upload_services[]="uploadjockey.com";
$max_file_size["uploadjockey.com"]=1000;
$page_upload["uploadjockey.com"] = "uploadjockey.com.php";  
?>