<?php
$upload_services[]="megashare.vnn.vn";
$max_file_size["megashare.vnn.vn"]=300;
$page_upload["megashare.vnn.vn"] = "megashare.vnn.vn.php";
?>