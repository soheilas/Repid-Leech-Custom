<?php 
$upload_services[]="fileflyer.com";
$max_file_size["fileflyer.com"]=2048;
$page_upload["fileflyer.com"] = "fileflyer.com.php";
?>