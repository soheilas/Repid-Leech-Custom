<?php
$upload_services[]="wat.tv_member";
$max_file_size["wat.tv_member"]=200;
$page_upload["wat.tv_member"] = "wat.tv_member.php";
?>