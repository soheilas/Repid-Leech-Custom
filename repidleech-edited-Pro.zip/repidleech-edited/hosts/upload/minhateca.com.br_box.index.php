<?php
$upload_services[] = 'minhateca.com.br_box';
$max_file_size['minhateca.com.br_box'] = 0;
$page_upload['minhateca.com.br_box'] = 'minhateca.com.br_box.php';
?>
