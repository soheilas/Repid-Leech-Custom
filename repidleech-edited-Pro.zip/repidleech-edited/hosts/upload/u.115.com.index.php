<?php 
$upload_services[] = "u.115.com";
$max_file_size["u.115.com"] = 1024;
$page_upload["u.115.com"] = "u.115.com.php";  
?>