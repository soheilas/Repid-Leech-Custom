<?
$upload_services[]="freakshare.com";
$max_file_size["freakshare.com"]=2048;
$page_upload["freakshare.com"] = "freakshare.com.php";
?>