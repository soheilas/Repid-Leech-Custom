<?php

$upload_services[] = 'rapidgator.net_member';
$max_file_size['rapidgator.net_member'] = 5120;
$page_upload['rapidgator.net_member'] = 'rapidgator.net_member.php';

?>