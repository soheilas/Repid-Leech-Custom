<?php
$upload_services[] = 'ex-load.com';
$max_file_size['ex-load.com'] = 2000;
$page_upload['ex-load.com'] = 'ex-load.com.php';
?>